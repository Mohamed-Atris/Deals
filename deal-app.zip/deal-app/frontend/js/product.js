// Example for loading products
document.addEventListener('DOMContentLoaded', async () => {
    try {
        const response = await fetch('/api/products');
        const products = await response.json();
        const productList = document.getElementById('productList');
        products.forEach(product => {
            const productItem = document.createElement('div');
            productItem.innerHTML = `
                <h2>${product.title}</h2>
                <p>${product.description}</p>
                <p>Price: $${product.price}</p>
                <p>Category: ${product.category}</p>
            `;
            productList.appendChild(productItem);
        });
    } catch (error) {
        console.error('Error:', error);
    }
});
