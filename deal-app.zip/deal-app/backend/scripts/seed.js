const mongoose = require('mongoose');
const User = require('../models/User');
const Product = require('../models/Product');
const { MONGO_URI } = require('../config/config');

mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(async () => {
        await User.deleteMany({});
        await Product.deleteMany({});
        
        // Seed data here
        const user = new User({ email: 'test@example.com', password: 'password' });
        await user.save();
        
        console.log('Seed data inserted');
        mongoose.connection.close();
    })
    .catch(err => console.error('Seed error:', err));
